module.exports = {
    name: 'useless',
    description: 'A completely useless command!',
    execute(message) {
        message.reply('This is a useless command! 🚀');
    },
};
