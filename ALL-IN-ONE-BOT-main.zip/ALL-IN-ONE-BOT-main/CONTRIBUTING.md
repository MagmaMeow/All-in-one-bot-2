🚫 You may not monetize, resell, or claim credit for this project.

✅ You may contribute improvements via pull requests if you agree to the AGPL-3.0 terms.
